import { FirebaseSetupInstructions } from "@/components/firebase-setup-instructions"

export default function SetupPage() {
  return <FirebaseSetupInstructions />
}
